// Sélection de la div pour l'affichage du résultat
const output = document.querySelector('.output');

// Sélection de tous les boutons
const keys = document.querySelectorAll('.keys div');

// Initialisation de la variable pour stocker les chiffres entrés
let input = '';

// Boucle pour ajouter un événement de clic à chaque bouton
keys.forEach(key => {
  key.addEventListener('click', () => {
    // Si l'utilisateur appuie sur le bouton "AC", on réinitialise l'input
    if (key.id === 'ac') {
      input = '';
      updateOutput();
    }
    // Si l'utilisateur appuie sur le bouton "+ / -", on inverse le signe de l'input
    else if (key.id === 'minus-m') {
      input = -parseFloat(input);
      updateOutput();
    }
    // Si l'utilisateur appuie sur le bouton "%", on calcule le pourcentage de l'input
    else if (key.id === 'percent') {
      input = parseFloat(input) / 100;
      updateOutput();
    }
    // Si l'utilisateur appuie sur le bouton "=", on calcule le résultat de l'opération
    else if (key.id === 'submit') {
      input = eval(input).toString();
      updateOutput();
    }
    // Sinon, on ajoute le chiffre ou l'opérateur correspondant à l'input
    else {
      input += key.textContent;
      updateOutput();
    }
  });
});

// Fonction pour mettre à jour l'affichage du résultat
function updateOutput() {
  output.textContent = input;
}
